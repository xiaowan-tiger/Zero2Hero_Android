package com.example.tempui_0821


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import android.util.Log

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TempScreen() }
    }
}

@Composable
fun TempScreen() {
    var tempC by remember { mutableStateOf(0) }
    var useFahrenheit by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {

//            val test = System.getProperty("ro.product.model")
//            Log.d("TempDebug", "test=$test")
//
//            val raw = System.getProperty("persist.sys.temp.current", "0")
//            Log.d("TempDebug","raw=$raw")

            val raw = getSystemProperty("persist.sys.temp.current", "0")
//            Log.d("TempDebug", "raw=$raw")
//
//            val test = getSystemProperty("ro.product.model", "unknown")
//            Log.d("TempDebug", "test=$test")

            tempC = raw.toIntOrNull() ?: 0
            delay(1000)
        }
    }

    val display = if (useFahrenheit) {
        "%.1f °F".format(tempC * 9.0 / 5 + 32)
    } else {
        "$tempC °C"
    }

    Column(
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
    ) {
        Text(display, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { useFahrenheit = !useFahrenheit }) {
            Text("Toggle °C / °F")
        }
    }
}

fun getSystemProperty(key: String, def: String): String {
    return try {
        val clazz = Class.forName("android.os.SystemProperties")
        val getMethod = clazz.getMethod("get", String::class.java, String::class.java)
        getMethod.invoke(null, key, def) as String
    } catch (e: Exception) {
        def
    }
}
